﻿using SchoolManagement.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolManagement.Models
{
    public class Student
    {
        [Key]
        public int StudentId { get; set; } 
        public string StudentCode { get; set; }
        [Required]
        public string FirstName { get; set; }

        public string? LastName { get; set; }

        [Required]
        public int Age { get; set; }

        [Required]
        public DateTime DOB { get; set; }

        [Required]
        public string Gender { get; set; }

        [Required, EmailAddress]
        public string Email { get; set; }

        [Required]
        [MaxLength(10)]
        public string Phone { get; set; }

        // Login Credentials
        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }

       
        public ICollection<Qualification> Qualifications { get; set; }
    }
}
