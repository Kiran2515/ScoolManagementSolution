﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolManagement.Models
{
    public class Qualification
    {
        [Key]
        public int QualificationId { get; set; }

        public string? CourseName { get; set; }
        public string? University { get; set; }
        public int YearOfPassing { get; set; }
        public decimal Percentage { get; set; }

        
        public int StudentId { get; set; }

        [ForeignKey("StudentId")]
        public Student Student { get; set; }
    }
}
