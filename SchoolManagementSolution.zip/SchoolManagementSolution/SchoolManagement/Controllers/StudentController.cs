﻿using Microsoft.AspNetCore.Mvc;
using SchoolManagement.Models;
using SchoolManagement.Services;

namespace SchoolManagement.Controllers
{
    public class StudentController : Controller
    {
        private readonly StudentService _service;

        public StudentController(StudentService service)
        {
            _service = service;
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(Student student)
        {
            await _service.Register(student);
            return RedirectToAction("Login");
        }

        
        public IActionResult Login()
        {
            return View();
        }

       
        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            var user = _service.Login(username, password);
            if (user != null)
                return RedirectToAction("List");

            ViewBag.Error = "Invalid username or password";
            return View();
        }

        public IActionResult List()
        {
            var data = _service.GetAll();
            return View(data);
        }
    }
}
