﻿using Microsoft.EntityFrameworkCore;
using SchoolManagement.Data;
using SchoolManagement.Models;

namespace SchoolManagement.Services
{
    public class StudentService
    {
        private readonly SchoolDbContext _context;

        public StudentService(SchoolDbContext context)
        {
            _context = context;
        }

        
        public async Task Register(Student student)
        {
            int count = _context.Students.Count() + 1;
            student.StudentCode = "STU" + count.ToString("000");

            _context.Students.Add(student);
            await _context.SaveChangesAsync();
        }

        
        public Student? Login(string username, string password)
        {
            return _context.Students
                .Include(s => s.Qualifications)
                .FirstOrDefault(x => x.Username == username && x.Password == password);
        }

        
        public List<Student> GetAll()
        {
            return _context.Students
                .Include(s => s.Qualifications)
                .ToList();
        }
    }
}
